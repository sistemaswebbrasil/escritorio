export default [
    {
        icon: "mdi-chart-gantt",
        text: "PlantumlSequence",
        link: "/uml/plantuml-sequence",
        key: "menu.plantumlSequence",
    },
    {
        icon: "mdi-lan",
        text: "PlantumlObject",
        link: "/uml/plantuml-object",
        key: "menu.plantumlObject",
    },
    {
        icon: "mdi-chart-timeline",
        text: "PlantumlTiming",
        link: "/uml/plantuml-Timing",
        key: "menu.plantumlTiming",
    },
];