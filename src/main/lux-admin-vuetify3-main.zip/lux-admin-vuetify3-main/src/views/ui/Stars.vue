<!--
* @Component: 
* @Maintainer: J.K. Yang
* @Description: 
-->
<script setup lang="ts"></script>

<template>
  <div class="">STATS</div>
</template>

<style scoped lang="scss"></style>
