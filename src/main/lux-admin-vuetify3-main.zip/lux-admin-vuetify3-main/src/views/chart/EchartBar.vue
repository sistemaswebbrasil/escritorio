<!--
* @Component: EchartPie
* @Maintainer: J.K. Yang
* @Description: Echart BarChart
-->

<script setup lang="ts">
import BarChart1 from "./component/BarChart1.vue";
import BarChart2 from "./component/BarChart2.vue";
</script>

<template>
  <v-container>
    <BarChart1 />
    <BarChart2 />
  </v-container>
</template>
