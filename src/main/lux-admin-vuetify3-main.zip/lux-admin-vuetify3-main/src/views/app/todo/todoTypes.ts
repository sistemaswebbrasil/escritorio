export interface Todo {
  id: string;
  title: string;
  detail: string;
  completed: boolean;
  tags: string[];
}
