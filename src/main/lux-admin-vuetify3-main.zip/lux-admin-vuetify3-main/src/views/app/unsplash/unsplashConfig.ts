export const BASE_URL = "https://api.unsplash.com/";
export const ACCESS_KEY = "mfB0t1DgccWtivNuh8KD06FMIZcun7vE_x_BSYQrfq8";

export const config = {
  headers: {
    Authorization: "Client-ID" + " " + ACCESS_KEY,
  },
};
