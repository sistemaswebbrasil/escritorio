<!--
* @Component: 
* @Maintainer: J.K. Yang
* @Description: 
-->
<script setup lang="ts"></script>

<template>
  <div class="">
    <v-card class="pa-5" height="500"> </v-card>
  </div>
</template>

<style scoped lang="scss"></style>
