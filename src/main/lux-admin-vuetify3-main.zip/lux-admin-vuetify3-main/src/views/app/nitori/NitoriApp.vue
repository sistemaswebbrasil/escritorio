<!--
* @Component: 
* @Maintainer: J.K. Yang
* @Description: Imitate Nitori App
-->
<script setup lang="ts"></script>

<template>
  <div class="">Nitori</div>
</template>

<style scoped lang="scss"></style>
