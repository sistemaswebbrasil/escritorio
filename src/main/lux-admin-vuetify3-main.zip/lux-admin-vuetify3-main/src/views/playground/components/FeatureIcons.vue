<!--
* @Component: 
* @Maintainer: J.K. Yang
* @Description: 
-->
<script setup lang="ts">
import { Icon } from "@iconify/vue";
</script>

<template>
  <div class=""></div>
</template>

<style scoped lang="scss"></style>
