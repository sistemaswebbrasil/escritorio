<template>
  <v-card
    variant="flat"
    height="100vh"
    class="d-flex justify-center align-center text-center"
  >
    <div>
      <img src="@/assets/images/500.svg" max-width="500" alt="500" />
      <h1 class="text-h1 pt-3">Opps!!!</h1>
      <h4 class="text-h4 my-8">
        This page you are looking for could not be found.
      </h4>
      <v-btn flat color="#705CF6" class="mb-4 text-white" to="/"
        >Go Back to Home</v-btn
      >
    </div>
  </v-card>
</template>
