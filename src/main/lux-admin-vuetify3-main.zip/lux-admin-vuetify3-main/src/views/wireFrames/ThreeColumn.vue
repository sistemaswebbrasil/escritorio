<template>
  <v-container>
    <v-row>
      <v-col class="d-none d-sm-block" sm="2">
        <v-sheet rounded="lg" min-height="268" color="red">
          <!--  -->
        </v-sheet>
      </v-col>
      <v-col cols="12" sm="10" md="8">
        <v-sheet min-height="70vh" rounded="lg" color="blue">
          <!--  -->
        </v-sheet>
      </v-col>

      <v-col class="d-none d-md-block" cols="12" md="2">
        <v-sheet rounded="lg" min-height="268" color="green">
          <!--  -->
        </v-sheet>
      </v-col>
    </v-row>
  </v-container>
</template>

<script setup lang="ts"></script>

<style></style>
