export const add = (a: number, b: number) => a + b;
