export default [
  {
    id: 1,
    name: "apple-music",
    logoUrl: "https://cdn.worldvectorlogo.com/logos/apple-music.svg",
  },
  {
    id: 2,
    name: "microsoft",
    logoUrl: "https://cdn.worldvectorlogo.com/logos/microsoft.svg",
  },
  {
    id: 3,
    name: "azure",
    logoUrl: "https://cdn.worldvectorlogo.com/logos/microsoft-azure-2.svg",
  },
  {
    id: 4,
    name: "google",
    logoUrl: "https://cdn.worldvectorlogo.com/logos/google-2015.svg",
  },
  {
    id: 5,
    name: "mastercard",
    logoUrl: "https://cdn.worldvectorlogo.com/logos/mastercard-2.svg",
  },
  {
    id: 6,
    name: "facebook",
    logoUrl: "https://cdn.worldvectorlogo.com/logos/facebook.svg",
  },
  {
    id: 7,
    name: "spotify",
    logoUrl: "https://cdn.worldvectorlogo.com/logos/spotify-1.svg",
  },
  {
    id: 8,
    name: "visa",
    logoUrl: "https://cdn.worldvectorlogo.com/logos/visa.svg",
  },
  {
    id: 9,
    name: "salesforce",
    logoUrl: "https://cdn.worldvectorlogo.com/logos/salesforce-2.svg",
  },
  {
    id: 10,
    name: "uber",
    logoUrl: "https://cdn.worldvectorlogo.com/logos/uber-2.svg",
  },
];
